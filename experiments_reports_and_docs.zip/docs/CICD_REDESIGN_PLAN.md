# CI/CD & MLOps Infrastructure Redesign Plan

This document outlines the architecture and execution strategy for the automated CI/CD and MLOps release pipelines in **PrismPrice**.

---

## End-to-End Pipeline Architecture

The project implements a 5-stage GitHub Actions automation pipeline:

```mermaid
flowchart TD
    subgraph Stage 1: Quality Gate
        A[Git Push / PR] --> B[ci.yml\nSyntax, Pytest & Repo Hygiene]
    end

    subgraph Stage 2: Scheduled Retrain
        C[Nightly Cron / Manual] --> D[training.yml\nPull Data via DVC & Train Model]
        D --> E[Log to MLflow & DagsHub]
    end

    subgraph Stage 3: Model Promotion
        E --> F[promote.yml\nValidate SMAPE vs Baseline]
        F --> G[Update Registry Index]
    end

    subgraph Stage 4: Continuous Deployment
        G --> H[deploy.yml\nBuild Package & Push to HF Space]
        H --> I[Poll /readyz Health Probe]
        I --> J[Live Prediction Probing]
    end

    subgraph Stage 5: Live Monitoring
        J --> K[health-check.yml & daily-monitoring.yml\nMonitor Latency & Drift Every 6 Hours]
    end
```

---

## Detailed Workflow Specifications

### 1. `ci.yml` — Code Quality & Syntax Gate
- **Trigger**: `pull_request` to `main`, `push` to `main`.
- **Actions**:
  - Sets up Python 3.10 environment.
  - Compiles all source files: `python -m compileall src main.py`.
  - Runs unit and integration tests: `pytest -q ci_cd/tests`.
  - Enforces repository hygiene: `python scripts/check_repo_hygiene.py`.
  - Validates CLI entrypoint `--help` flag.

---

### 2. `training.yml` — Automated Model Retraining
- **Trigger**: Scheduled daily cron at `22:00 UTC` or `workflow_dispatch`.
- **Actions**:
  - Configures AWS & DVC credentials.
  - Pulls latest raw/interim datasets: `dvc pull`.
  - Executes feature pipeline and model training (`main.py train`).
  - Logs parameters, metrics (CV SMAPE), and feature dimensions to MLflow / DagsHub.
  - Generates immutable run bundle and registers candidate run.

---

### 3. `promote.yml` — Model Validation & Stage Promotion
- **Trigger**: Manual trigger (`workflow_dispatch`) with inputs `run_id` and `stage` (`staging` / `production`).
- **Actions**:
  - Compares candidate run metrics against current production baseline.
  - Verifies SLO latency and accuracy rules via `src/validation/`.
  - Updates `experiments/registry/index.json` and appends audit record to `promotion_history.jsonl`.
  - Triggers downstream deployment workflow (`deploy.yml`).

---

### 4. `deploy.yml` — Live Serving Deployment
- **Trigger**: Triggered automatically on `production` model promotion.
- **Actions**:
  - Assembles standalone deployment package using `scripts/create_hf_space_package.py`.
  - Pushes package to Hugging Face Space repository.
  - Polls `/readyz` endpoint until service reports `HTTP 200`.
  - Executes live synthetic prediction probes (`src/utils/live_probes.py`).
  - Updates `deployment_manifest.json`.
  - **Automated Rollback**: If health probes or live prediction calls fail, automatically executes `python main.py rollback --to-previous`.

---

### 5. `health-check.yml` & `daily-monitoring.yml` — Live Telemetry
- **Trigger**: Recurring cron every 6 hours.
- **Actions**:
  - Probes live endpoint `/healthz`, `/readyz`, and `/metrics/json`.
  - Monitors P95 latency and error rate metrics.
  - Logs system telemetry to `experiments/monitoring/`.
