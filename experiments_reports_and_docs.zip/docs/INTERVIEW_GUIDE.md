# Technical Deep-Dive & System Design Interview Guide

This guide is designed for technical interview preparation, portfolio reviews, and architecture deep-dives for **PrismPrice**.

---

## 1. The 30-Second Elevator Pitch

> "PrismPrice is an end-to-end MLOps platform for estimating product prices using text, visual embeddings, and parsed unit signals. Built to bridge the gap between notebook-level experimentation and production deployment, it integrates end-to-end training pipelines, stacking ensembles, immutable model bundle packaging, a versioned model registry, a FastAPI serving microservice, an interactive Web Dashboard, and automated CI/CD quality gates with live probes and zero-downtime deployment."

---

## 2. Tech Stack Rationales ("Why This Tool?")

### Core Language & Runtime: Python 3.10+
- **Why**: Python dominates the machine learning ecosystem with battle-tested libraries (LightGBM, XGBoost, CatBoost, scikit-learn, PyTorch, FastAPI).
- **Why not Java/Go**: While Java/Go are excellent for high-throughput platform services, Python provides vastly superior ML experimentation speed and model serialization tooling.

### Tabular & Gradient-Boosted Models: LightGBM, XGBoost, CatBoost
- **Why**: Heterogeneous tabular data containing engineered numeric metrics alongside dense embeddings benefits significantly from gradient-boosted decision trees over pure deep neural nets.
- **Why Stacking**: Combining LightGBM, XGBoost, and CatBoost out-of-fold predictions via a meta-learner consistently outperforms single models while mitigating variance.

### Text Embeddings: Sentence-Transformers (SBERT) + TF-IDF
- **Why**: SBERT provides deep semantic similarity for generic catalog titles (e.g., matching *"organic green tea"* to *"herbal matcha bags"*), while TF-IDF captures exact high-frequency keyword tokens deterministically.

### Online Serving: FastAPI + Uvicorn
- **Why**: Native support for async processing, automatic Pydantic request validation, high P99 throughput, built-in OpenAPI documentation, and effortless middleware design.
- **Why not Flask**: Flask lacks native async capabilities and automatic request schema validation out-of-the-box.

### MLOps: DVC + MLflow + GitHub Actions + Docker
- **Why DVC**: Keeps heavy datasets and binary model weights out of Git history while ensuring 100% reproducible data lineage via pointer files.
- **Why MLflow**: Enables experiment tracking, parameter logging, and cross-run comparison.
- **Why GitHub Actions**: Provides automated quality gates, model SLO validation, and zero-downtime deployments.

---

## 3. Key System Design Trade-Offs

| Decision Area | Chosen Approach | Alternative Considered | Rationale for Choice |
| :--- | :--- | :--- | :--- |
| **Model Packaging** | Immutable Run Bundles | Generic Pickle Weights | Bundling feature transformers, scalers, schema rules, and model weights together guarantees 100% offline/online parity. |
| **Model Evaluation** | SMAPE (Symmetric MAE %) | RMSE / MAE | SMAPE normalizes percentage errors across wide price ranges (e.g., $5 item vs $500 item), preventing high-priced items from dominating loss gradients. |
| **Model Registry** | Lightweight JSON File Registry | Heavy MLflow Registry Server | Simple file-based index (`experiments/registry/index.json`) stored in repository Git history avoids infrastructure cost and server dependencies. |
| **Serving Architecture** | Modular FastAPI Microservice | Microservice Mesh | Ideal balance of velocity and maintainability for early-to-mid stage production workloads, with a clear path to microservice decomposition. |

---

## 4. Common Technical Interview Questions & Answers

### Q1: How do you prevent data leakage during feature engineering and out-of-fold stacking?
> **Answer**: All vectorizers (TF-IDF), scalers (`StandardScaler`), and SVD transformers are fitted strictly inside each cross-validation fold training split. For stacking, meta-models are trained exclusively on out-of-fold (OOF) predictions generated during CV, ensuring the stacker never sees in-sample predictions.

### Q2: What happens if an image URL is broken or missing during online prediction?
> **Answer**: `src/features/image_embeddings.py` implements a graceful fallback mechanism. If an image is missing, unreachable, or fails decoding, the feature builder automatically substitutes a zero-filled vector matching the expected embedding dimension without crashing the request pipeline.

### Q3: How do you handle schema drifts or unexpected input fields in the API?
> **Answer**: FastAPI uses Pydantic schemas for runtime validation (`src/serving/app.py`). Incoming requests pass through `src/utils/column_aliases.py` to map field aliases automatically (e.g. `Description` ➔ `catalog_content`). Missing non-critical fields receive default values, while unparseable payloads are flagged and quarantined.

### Q4: How is deployment safety guaranteed in your CI/CD pipeline?
> **Answer**: When a candidate run is promoted, the `deploy.yml` workflow deploys the bundle to Hugging Face Spaces and waits for the `/readyz` endpoint to return `HTTP 200`. It then executes automated live prediction probes. If probing fails, GitHub Actions triggers an automated rollback script (`python main.py rollback --to-previous`).
