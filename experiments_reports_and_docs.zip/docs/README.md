# PrismPrice — Documentation Hub

Welcome to the central documentation hub for **PrismPrice**, an end-to-end Multimodal Product Price Intelligence Platform. This index provides an organized guide to all architectural, operational, onboarding, and MLOps documentation across the repository.

---

## Documentation Navigation Matrix

| Document | Target Audience | Key Topics Covered | Link |
| :--- | :--- | :--- | :--- |
| **Main Project README** | Everyone | Overview, Quick Start, Architecture, CLI Commands, Serving & UI | [README.md](../README.md) |
| **Architecture Context** | Architects, Data Engineers | Full system design, data schema, module breakdowns, algorithms | [`docs/ARCHITECTURE_CONTEXT.md`](ARCHITECTURE_CONTEXT.md) |
| **Developer Onboarding** | New Contributors, Engineers | Environment setup, pipeline execution, contributing guidelines | [`docs/DEVELOPER_ONBOARDING.md`](DEVELOPER_ONBOARDING.md) |
| **Cloud Training Runbook** | ML Engineers, Data Scientists | Kaggle/Colab training, DagsHub tracking, DVC push, promotion | [`docs/RUNBOOK_CLOUD_NOTEBOOKS.md`](RUNBOOK_CLOUD_NOTEBOOKS.md) |
| **Interview & Deep-Dive** | Technical Interviewers, Lead Engineers | System elevator pitch, tech stack rationales, trade-offs, Q&A | [`docs/INTERVIEW_GUIDE.md`](INTERVIEW_GUIDE.md) |
| **CI/CD & MLOps Plan** | MLOps / DevOps Engineers | GitHub Actions workflows, Hugging Face deployment, probes | [`docs/CICD_REDESIGN_PLAN.md`](CICD_REDESIGN_PLAN.md) |

---

## Detailed Documentation Index

### 1. System Architecture & Engineering Context
- **File**: [`docs/ARCHITECTURE_CONTEXT.md`](ARCHITECTURE_CONTEXT.md)
- **Description**: In-depth blueprint of the codebase architecture. Covers the canonical data schema (`sample_id`, `catalog_content`, `image_link`, `price`), schema normalization via `src/utils/column_aliases.py`, feature engineering pipelines (TF-IDF, SBERT, unit regex parsing, image embeddings), stacked ensemble mechanics (CV out-of-fold matrix generation, LightGBM/XGBoost/CatBoost stackers), and immutable run bundle creation (`experiments/runs/<run_id>/bundle`).

> [!NOTE]
> View high-level system diagrams in [`docs/system_archit.png`](system_archit.png) and component diagrams in [`docs/System_architecture.png`](System_architecture.png).

---

### 2. Developer Onboarding & Technical Handover
- **File**: [`docs/DEVELOPER_ONBOARDING.md`](DEVELOPER_ONBOARDING.md)
- **Description**: Comprehensive guide for engineers joining the project. Includes step-by-step local setup, virtual environment management, dataset setup via DVC, running training & inference CLI pipelines, executing test suites via `pytest`, and maintaining code hygiene.

---

### 3. Cloud Training Runbook (Kaggle / Colab -> DVC / MLflow)
- **File**: [`docs/RUNBOOK_CLOUD_NOTEBOOKS.md`](RUNBOOK_CLOUD_NOTEBOOKS.md)
- **Description**: Operational runbook for training compute-heavy multimodal models on free cloud GPUs (Kaggle / Google Colab). Explains how to log metrics and parameters to DagsHub MLflow, push feature caches to DVC, update DVC pointer files in Git, and trigger automated model promotion and Hugging Face Space deployment via GitHub Actions.

---

### 4. Technical Deep-Dive & Interview Guide
- **File**: [`docs/INTERVIEW_GUIDE.md`](INTERVIEW_GUIDE.md)
- **Description**: Structured system design and architecture reference designed for portfolio reviews and technical interviews. Features:
  - 30-second Elevator Pitch.
  - Comprehensive **Tech Stack Rationales** (Why FastAPI vs Flask, why DVC, why LightGBM/CatBoost over neural net-only, why SMAPE evaluation).
  - Production trade-offs and scaling strategies (1M+ DAU architecture with Redis & Kafka).
  - Common technical interview questions & answers.

---

### 5. CI/CD & MLOps Infrastructure Redesign
- **File**: [`docs/CICD_REDESIGN_PLAN.md`](CICD_REDESIGN_PLAN.md)
- **Description**: Architectural specification for the 5-stage GitHub Actions automation pipeline:
  1. `ci.yml` — Code compilation, pytest gates, and repository hygiene.
  2. `training.yml` — Scheduled/automated retraining & MLflow logging.
  3. `promote.yml` — Model validation against production thresholds & registry updating.
  4. `deploy.yml` — Hugging Face Space deployment, live health probes (`/readyz`), and rollback handling.
  5. `health-check.yml` & `daily-monitoring.yml` — Continuous probe verification and latency monitoring.

---

## Quick Start Guide Map

```mermaid
flowchart TD
    A[New to the project?] -->|Read Overview| B[README.md]
    A -->|Set up local dev| C[docs/DEVELOPER_ONBOARDING.md]
    
    D[Want to train on Kaggle/Colab?] -->|Follow Runbook| E[docs/RUNBOOK_CLOUD_NOTEBOOKS.md]
    
    F[Preparing for Architecture Review?] -->|Study Specs| G[docs/ARCHITECTURE_CONTEXT.md]
    F -->|Review Interview Guide| H[docs/INTERVIEW_GUIDE.md]
    
    I[Inspecting MLOps Automation?] -->|Examine CI/CD| J[docs/CICD_REDESIGN_PLAN.md]
```

---

## Documentation Hygiene & Maintenance

To maintain high documentation quality:
- Keep all CLI flags and code paths aligned with `main.py` and `configs/`.
- Ensure all relative markdown links remain valid when adding new documents.
- Run `python scripts/check_repo_hygiene.py` before submitting documentation updates.
