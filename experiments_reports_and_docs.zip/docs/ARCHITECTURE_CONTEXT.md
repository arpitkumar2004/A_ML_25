# PrismPrice — Architectural Context & System Architecture

This document provides a technical deep-dive into the architecture, data flows, feature engineering mechanics, model orchestration, and registry state management of **PrismPrice**.

---

## System Snapshot

- **Repository**: `A_ML_25`
- **Primary Objective**: Multimodal product price estimation combining text descriptions, visual image representations, and domain-parsed numeric signals.
- **Optimization Metric**: **SMAPE** (Symmetric Mean Absolute Percentage Error — lower is better).
- **Core Stack**: Python 3.10+, scikit-learn, LightGBM, XGBoost, CatBoost, SentenceTransformers, FastAPI, MLflow, DVC.
- **Primary Operational Modes**: Offline batch training, out-of-fold stacking, batch inference, online REST serving, and automated CI/CD releases.

---

## High-Level System Architecture

```mermaid
flowchart TB
    subgraph Data Layer
        A[Raw Input Data\ntrain.csv / test.csv] --> B[Schema Alias Normalizer\nsrc/utils/column_aliases.py]
        B --> C[Dataset Loader\nsrc/data/dataset_loader.py]
    end

    subgraph Feature Engineering Pipeline
        C --> D[Regex Unit & Numeric Parser\nsrc/data/parse_features.py]
        C --> E[Text Feature Builder\nTF-IDF & SBERT Embeddings]
        C --> F[Image Feature Builder\nResNet / CLIP Embeddings]
        
        D --> G[Multimodal Feature Assembler\nsrc/features/build_features.py]
        E --> G
        F --> G
    end

    subgraph Modeling & Bundle Generation
        G --> H[Model Trainer & K-Fold CV\nsrc/training/trainer.py]
        H --> I[Out-of-Fold Matrix\nexperiments/oof/]
        I --> J[Stacking Ensemble Meta-Model\nsrc/models/stacker.py]
        J --> K[Immutable Run Bundle\nexperiments/runs/RUN_ID/bundle]
    end

    subgraph Registry & Serving
        K --> L[Model Registry\nexperiments/registry/index.json]
        L --> M[FastAPI Online Service\nsrc/serving/app.py]
        L --> N[Batch Inference Pipeline\nsrc/pipelines/inference_pipeline.py]
        M --> O[Web Dashboard UI\nfrontend/index.html]
    end
```

---

## Data Contract & Canonical Schema

To decouple raw dataset formats (e.g., Kaggle, internal DB dumps, third-party vendor catalogs) from downstream feature builders, incoming data is normalized into a strict canonical schema.

### Canonical Columns

| Canonical Field | Type | Description |
| :--- | :--- | :--- |
| `sample_id` | `String` / `Int` | Unique product sample identifier |
| `catalog_content` | `String` | Product title, bullet points, and description |
| `image_link` | `String` | Local path or remote URL to product image |
| `price` | `Float` | Target ground truth price (training only) |

### Schema Normalization (`src/utils/column_aliases.py`)

Automatic mapping handles raw vendor column variations:
- `unique_identifier`, `id`, `product_id` ➔ `sample_id`
- `Description`, `title`, `text`, `catalog_text` ➔ `catalog_content`
- `image_path`, `image_url`, `img_link` ➔ `image_link`
- `Price`, `target_price`, `cost` ➔ `price`

---

## Multimodal Feature Engineering

The feature engineering layer transforms unstructured and structured catalog data into high-dimensional feature matrices:

### 1. Regex Numeric & Unit Signal Parser (`src/data/parse_features.py`)
Parses physical domain signals directly from raw text:
- **Weights**: Normalized to grams (`parsed_total_weight_g`).
- **Volumes**: Normalized to milliliters (`parsed_total_volume_ml`).
- **Counts**: Pack and item unit counts (`parsed_total_count_units`).
- **Derived Features**: `parsed_quantity_mentions`, `parsed_has_quantity`.
- **Log Transforms**: Applies `log1p` transforms to mitigate skewness (`parsed_value_log1p`, `parsed_weight_log1p`, `parsed_volume_log1p`).

### 2. Text Embeddings (`src/features/text_embeddings.py`)
- **TF-IDF**: Persisted `TfidfVectorizer` (unigrams & bigrams) maintaining exact feature parity between training and online inference.
- **SBERT Embeddings**: Dense 384-dimensional semantic vectors using `SentenceTransformers` (`all-MiniLM-L6-v2`).

### 3. Image Embeddings (`src/features/image_embeddings.py`)
- Pretrained vision encoders (ResNet-50 / CLIP) extract visual feature vectors.
- Features graceful zero-vector fallback for missing or corrupted image URLs.

### 4. Dimensionality Reduction & Concatenation (`src/features/build_features.py`)
- Applies `TruncatedSVD` / `PCA` to high-dimensional text/image matrices before concatenating with scaled numeric features.

---

## Model Training, Stacking & Immutable Bundles

### K-Fold Cross-Validation (`src/training/trainer.py`)
- Runs Stratified or Group K-Fold cross-validation over the training dataset.
- Primary evaluation metric: **SMAPE** (Symmetric Mean Absolute Percentage Error).
- Generates out-of-fold (OOF) prediction matrices saved to `experiments/oof/`.

### Stacking Ensemble (`src/models/stacker.py`)
- Meta-learner trained on OOF prediction matrices from diverse base models:
  - **LightGBM**
  - **XGBoost**
  - **CatBoost**
  - **Random Forest**
  - **Ridge Regression**

### Immutable Run Bundles
Every training run packages all assets into a run-scoped bundle under `experiments/runs/<run_id>/bundle/`:

```text
experiments/runs/<run_id>/bundle/
├── bundle_meta.json           # Run metadata, git commit hash, SMAPE score
├── feature_pipeline.joblib    # Persisted vectorizers, scalers, and SVD models
├── model.joblib               # Trained model / stacker weights
└── schema_rules.json          # Required feature columns & data types
```

---

## Model Registry & State Store

The repository uses a transparent, file-based JSON registry located in `experiments/registry/`:

```text
experiments/registry/
├── index.json                 # Active registry pointers (staging / production)
├── promotion_history.jsonl    # Audit log of stage transitions and approvals
├── deployment_manifest.json   # Records active deployment URL, bundle hash & timestamp
└── production_tracker.json    # Records live P95 latency and baseline metric drift
```

### Stage Promotion Flow
1. **Candidate Training**: Run created and logged to MLflow & registry.
2. **SLO Validation**: Evaluated against accuracy and latency gates (`src/validation/`).
3. **Promotion**: CLI command `python main.py promote --run-id <run_id> --stage production` updates `index.json`.
4. **Rollback**: CLI command `python main.py rollback --to-previous` reverts production pointer in `index.json`.

---

## FastAPI Online Serving & Monitoring

Located in `src/serving/app.py`, the microservice provides real-time inference and monitoring:

- `GET /healthz` — Basic liveness probe.
- `GET /readyz` — Readiness probe verifying immutable bundle loading.
- `GET /service/info` — Returns active run ID, bundle hash, and model stage.
- `GET /metrics/json` — Returns request counts, latency distribution (P50/P95/P99), and error rates.
- `POST /v1/predict` — Real-time price prediction endpoint with batch support.

---

## Production Infrastructure (Target Topology)

For large-scale deployment (1M+ DAU, P99 < 1s latency):

1. **API Gateway / Load Balancer**: Handles SSL termination and rate limiting.
2. **Redis Feature Store**: Caches precomputed SBERT and image vectors for sub-millisecond feature lookup.
3. **Async Processing Queue**: Kafka / Celery worker pool for heavy image downloads and offline re-embeddings.
4. **Observability Pipeline**: Prometheus metrics scraping `/metrics/json` paired with Grafana dashboards and Evidently AI drift detection.
