# Developer Onboarding & Technical Handover Guide

Welcome to **PrismPrice**! This document serves as the primary technical onboarding guide for developers, data scientists, and MLOps engineers joining the team.

---

## Quick Orienting Checklist

Before making your first pull request, complete this 5-step checklist:

- [ ] Clone repository & create Python 3.10+ virtual environment.
- [ ] Install dependencies via `pip install -r requirements.txt`.
- [ ] Run code compilation smoke test: `python -m compileall src main.py`.
- [ ] Run automated pytest suite: `pytest -q ci_cd/tests`.
- [ ] Execute repo hygiene check: `python scripts/check_repo_hygiene.py`.

---

## Local Environment Setup

### 1. Prerequisites
- **Python**: Version 3.10 or higher.
- **Git**: Version 2.30 or higher.
- **Virtual Environment**: `venv` or `conda`.

### 2. Environment Initialization

```bash
# Clone repository
git clone https://github.com/arpitkumar2004/A_ML_25.git
cd A_ML_25

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# Windows PowerShell:
.venv\Scripts\activate
# Linux / macOS:
source .venv/bin/activate

# Upgrade pip & install requirements
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Environment Variables Configuration
Copy the template configuration file:

```bash
# Linux/macOS:
cp .env.example .env

# Windows PowerShell:
Copy-Item .env.example .env
```

> [!IMPORTANT]
> Never commit `.env` files to Git repository tracking. `.env` is explicitly ignored in `.gitignore`.

---

## CLI Operations Cheat Sheet

All major operations are accessible through `main.py`:

### 1. Training Pipeline
Train baseline models and stacking ensembles defined in config:

```bash
# Train complete model suite
python main.py train --config configs/training/final_train.yaml

# Train specific model family (e.g., LightGBM)
python main.py train --config configs/training/final_train.yaml --model lgbm
```

### 2. Feature Building
Generate and cache feature matrices:

```bash
python main.py features --config configs/features/all_features.yaml
```

### 3. Stacking Ensemble
Train stacker meta-model on generated out-of-fold predictions:

```bash
python main.py ensemble --config configs/model/ensemble.yaml
```

### 4. Offline Batch Inference
Generate price predictions for test data:

```bash
python main.py inference --config configs/inference/inference.yaml
```

### 5. Quick Smoke Test
Run an end-to-end synthetic train/inference pipeline test:

```bash
python main.py quickrun
```

---

## Online Serving & Local API Testing

Start the FastAPI serving service locally:

```bash
uvicorn src.serving.app:app --host 0.0.0.0 --port 8000 --reload
```

### Verify Endpoints
- **Liveness**: `curl http://127.0.0.1:8000/healthz`
- **Readiness**: `curl http://127.0.0.1:8000/readyz`
- **Service Info**: `curl http://127.0.0.1:8000/service/info`
- **Metrics**: `curl http://127.0.0.1:8000/metrics/json`

### Test Sample Inference Request

```bash
curl -X POST "http://127.0.0.1:8000/v1/predict" \
     -H "Content-Type: application/json" \
     -d '{
       "records": [
         {
           "unique_identifier": "TEST_001",
           "Description": "Pack of 12 Organic Earl Grey Tea Bags 50g",
           "image_path": ""
         }
       ]
     }'
```

---

## Testing & Quality Assurance

The test suite is located in `ci_cd/tests/` and built with `pytest`:

```bash
# Run complete test suite
pytest -q ci_cd/tests

# Run specific test file
pytest ci_cd/tests/test_serving.py

# Check repository hygiene
python scripts/check_repo_hygiene.py
```

---

## Daily Git & DVC Workflow

Large data files (`.csv`, `.joblib`) are versioned with **DVC**:

```bash
# 1. Pull code & binary assets
git pull
dvc pull

# 2. Add modified datasets to DVC
dvc add data/raw/train.csv
dvc add data/processed/features.joblib

# 3. Commit pointer changes to Git
git add data/raw/train.csv.dvc data/processed/features.joblib.dvc .gitignore
git commit -m "feat: update data artifacts"

# 4. Push binary payloads to DVC remote & code to Git
dvc push
git push
```

---

## Coding Standards & Guidelines

1. **Modular Architecture**: All reusable logic belongs in domain modules under `src/` (`src/data/`, `src/features/`, `src/models/`, `src/serving/`).
2. **Type Annotations**: Use Python type hints on public function signatures.
3. **Immutability**: Never overwrite existing model run bundles in `experiments/runs/`. Always output to a new timestamped `run_id`.
4. **Clean Commits**: Ensure `python scripts/check_repo_hygiene.py` returns `REPO_HYGIENE_OK` before opening a Pull Request.
