# Cloud Training & Deployment Runbook

**Target Environments**: Kaggle Notebooks, Google Colab (GPU/TPU acceleration)  
**Integrations**: MLflow + DagsHub (Experiment Tracking), DVC + S3/DagsHub (Data & Model Storage), GitHub Actions (Promotion & HF Space Deployment)

---

## Purpose & Overview

This operational runbook provides a step-by-step procedure for executing compute-heavy multimodal training runs on free cloud notebook environments (Kaggle or Google Colab), logging experiments to DagsHub, pushing model artifacts via DVC, and promoting candidates to live production serving targets via GitHub Actions.

```mermaid
flowchart LR
    A[Kaggle / Colab Notebook\nGPU Accelerated Training] -->|Log Metrics & Parameters| B[DagsHub MLflow Remote]
    A -->|Push Binary Bundles & Data| C[DVC Remote Storage]
    A -->|Commit .dvc Pointers| D[GitHub Repository]
    D -->|Trigger promote.yml| E[Model Promotion Gate]
    E -->|Trigger deploy.yml| F[Hugging Face Space Live Deployment]
```

---

## Pre-Flight Checklist

Before launching a cloud notebook run, ensure:

- [ ] GitHub repository is up-to-date (`arpitkumar2004/A_ML_25`).
- [ ] DagsHub access token is generated.
- [ ] DVC remote bucket storage credentials are configured.
- [ ] GitHub repository secrets are set (`DAGSHUB_TOKEN`, `HF_TOKEN`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`).

---

## 1. Notebook Initialization Script

Copy and execute the following Python block in your initial notebook cell (Kaggle / Colab):

```python
import os
from pathlib import Path

# 1. Clone codebase
!git clone https://github.com/arpitkumar2004/A_ML_25.git
%cd A_ML_25

# 2. Install core requirements & tracking toolkits
!python -m pip install --upgrade pip
!pip install -r requirements.txt
!pip install dvc[s3] mlflow dagshub

# 3. Create .env file for environment variables (NEVER commit this file!)
env_content = """
MLFLOW_ENABLED=1
DAGSHUB_MLFLOW_ENABLED=1
DAGSHUB_REPO_OWNER=arpitkumar2004
DAGSHUB_REPO_NAME=A_ML_25
DAGSHUB_TOKEN=YOUR_DAGSHUB_ACCESS_TOKEN
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY
AWS_DEFAULT_REGION=us-east-1
PYTHONPATH=.
"""

with open(".env", "w") as f:
    f.write(env_content.strip())

print("Environment setup complete.")
```

> [!CAUTION]
> Never commit notebook checkpoints containing exposed tokens or credentials to public repositories.

---

## 2. Execute Cloud Training Pipeline

Execute training CLI directly inside the notebook:

```python
# 1. Pull DVC binary data assets
!dvc pull

# 2. Run feature extraction
!python main.py features --config configs/features/all_features.yaml

# 3. Execute canonical multimodal training
!python main.py train --config configs/training/final_train.yaml

# 4. Train stacking ensemble
!python main.py ensemble --config configs/model/ensemble.yaml
```

---

## 3. Save Artifacts to DVC & MLflow

After training completes, sync your results:

```python
# 1. Track new model bundles & features with DVC
!dvc add experiments/runs/
!dvc add data/processed/

# 2. Push binary artifacts to DVC remote storage
!dvc push

# 3. Display run ID for promotion
import json
with open("experiments/registry/index.json") as f:
    reg = json.load(f)
    print("Candidate Run ID:", reg.get("latest_run_id"))
```

---

## 4. Trigger GitHub Model Promotion & Live Deployment

Once metrics are verified on DagsHub MLflow UI:

### Option A: Via GitHub Web Interface
1. Go to repository **Actions** tab.
2. Select **Model Promotion Workflow** (`promote.yml`).
3. Click **Run workflow**, enter `RUN_ID`, select stage `production`.

### Option B: Via `gh` CLI

```bash
gh workflow run promote.yml -f run_id=train_20260325T155219Z -f stage=production
```

The promotion workflow will automatically trigger `deploy.yml` to package and push the immutable bundle to Hugging Face Spaces with live health probing (`/readyz`) and automated rollback protection.
